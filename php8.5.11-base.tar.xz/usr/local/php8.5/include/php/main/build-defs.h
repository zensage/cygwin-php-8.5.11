/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=/usr/local/php8.5' '--enable-shared' '--disable-static' '--disable-rpath' '--disable-fiber-asm' '--disable-all' '--with-pear' '--enable-cli' '--enable-cgi' '--enable-fpm' '--with-fpm-acl' '--enable-embed' '--enable-phpdbg' '--with-external-pcre' '--with-config-file-path=/usr/local/php8.5/etc' '--with-config-file-scan-dir=/usr/local/php8.5/etc/php.d' '--enable-filter' '--enable-ctype' '--with-zlib' '--with-openssl' '--enable-tokenizer' '--enable-posix' '--enable-bcmath' '--enable-sockets' '--enable-exif' '--enable-xml' '--with-libxml' '--enable-simplexml' '--enable-xmlwriter' '--with-iconv=static,/usr' '--enable-mbstring=shared' '--enable-intl=shared' '--enable-phar=shared' '--with-zip=shared' '--with-curl=shared' '--enable-pdo' '--enable-session' '--enable-dom' '--enable-xmlreader=shared' '--enable-gd=shared' '--with-external-gd' '--with-sodium=shared,/usr' '--with-sqlite3=shared,/usr' '--with-pdo-sqlite=shared,/usr' '--with-ffi=shared,/usr' '--with-bz2=shared,/usr' '--with-gettext=shared,/usr' '--enable-fileinfo=shared' '--with-gmp=shared,/usr' '--with-tidy=shared,/usr' '--with-mysqli=shared,mysqlnd' '--with-pdo-mysql=shared,mysqlnd' '--with-pdo-pgsql=shared,/usr' '--with-pgsql=shared,/usr' '--with-imap=shared,/usr' 'ac_cv_func_ttyname_r_works=yes'"
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "/usr/local/php8.5/lib/php"
#define PHP_INCLUDE_PATH	".:/usr/local/php8.5/lib/php"
#define PHP_EXTENSION_DIR       "/usr/local/php8.5/lib/php/extensions/no-debug-non-zts-20250925"
#define PHP_PREFIX              "/usr/local/php8.5"
#define PHP_BINDIR              "/usr/local/php8.5/bin"
#define PHP_SBINDIR             "/usr/local/php8.5/sbin"
#define PHP_MANDIR              "/usr/local/php8.5/php/man"
#define PHP_LIBDIR              "/usr/local/php8.5/lib/php"
#define PHP_DATADIR             "/usr/local/php8.5/share/php"
#define PHP_SYSCONFDIR          "/usr/local/php8.5/etc"
#define PHP_LOCALSTATEDIR       "/usr/local/php8.5/var"
#define PHP_CONFIG_FILE_PATH    "/usr/local/php8.5/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/usr/local/php8.5/etc/php.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
