#!/bin/bash
PREFIX="/usr/local/php8.5"
for l in /usr/bin/php /usr/bin/php-cgi /usr/bin/phpdbg \
         /usr/bin/php-config /usr/bin/phpize /usr/sbin/php-fpm; do
    if [ -L "$l" ]; then
        case "$(readlink "$l")" in
            "$PREFIX"/*) rm -f "$l"; echo "[php-base preremove] removed $l" ;;
        esac
    fi
done
echo "[php-base preremove] 旧版本 /usr/bin/php*_<ver>.exe 未还原,如需恢复请手动改名/建链接"
exit 0
