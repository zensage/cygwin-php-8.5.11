#!/bin/bash
# php-base postinstall (可重复执行)
PREFIX="/usr/local/php8.5"
PKGVER="8.5.11"
PHP_EXE="$PREFIX/bin/php.exe"
INI_DIR="$PREFIX/etc/php.d"
OLDVER=""
OLDSUF=""

log() { echo "[php-base postinstall] $*"; }

# ---- 1. 收集 dll,rebase 防止 fork 时地址冲突 ----
EXT_DIR=""
for d in "$PREFIX"/lib/php/extensions/*/; do
    [ -d "$d" ] && { EXT_DIR="${d%/}"; break; }
done

DLL_LIST=/tmp/php-base-dlls.$$
: > "$DLL_LIST"
[ -f "$PREFIX/bin/cygphp.dll" ] && echo "$PREFIX/bin/cygphp.dll" >> "$DLL_LIST"
[ -n "$EXT_DIR" ] && find "$EXT_DIR" -maxdepth 1 -name '*.dll' >> "$DLL_LIST"

if command -v rebase >/dev/null 2>&1 && [ -s "$DLL_LIST" ]; then
    log "rebase $(wc -l < "$DLL_LIST") 个 dll"
    rebase -s -T "$DLL_LIST" >/dev/null 2>&1 \
        || log "WARN: rebase 失败(可能有 dll 正被占用),请关闭 Cygwin 进程后手动执行: rebase -s -T $DLL_LIST"
else
    log "WARN: 未安装 rebase 包,跳过(建议 apt-cyg install rebase 后重装本包)"
fi

# ---- 2. 按现有 dll 生成 ini(已有同名 ini 则保留) ----
mkdir -p "$INI_DIR"
if [ -n "$EXT_DIR" ]; then
    for dll in "$EXT_DIR"/*.dll; do
        [ -f "$dll" ] || continue
        name="$(basename "$dll" .dll)"
        if ls "$INI_DIR" 2>/dev/null | grep -qE "^[0-9]+-${name}\.ini$"; then
            continue
        fi
        case "$name" in
            pdo_*) prio=30 ;;
            *)     prio=20 ;;
        esac
        echo "extension=${name}" > "$INI_DIR/${prio}-${name}.ini"
        log "生成 ini: ${prio}-${name}.ini"
    done
fi

# ---- 3. 旧的 /usr/bin/phpxxx(.exe) 统一改名为 phpxxx_<ver>.exe ----
detect_ver() {
    local f="$1" opt v
    for opt in -v --version; do
        v="$("$f" $opt 2>/dev/null </dev/null | grep -o 'PHP [0-9]\+\.[0-9]\+\.[0-9]\+' | head -1 | cut -d' ' -f2)"
        if [ -n "$v" ]; then echo "$v"; return 0; fi
    done
    return 1
}

relocate_exe() {
    local name="$1" dir="$2" cand real ver base suf dest
    for cand in "$dir/$name.exe" "$dir/$name"; do
        [ -e "$cand" ] || [ -L "$cand" ] || continue
        real="$(readlink -f "$cand")"
        case "$real" in
            "$PREFIX"/*) rm -f "$cand"; continue ;;       # 本包以前建的链接
        esac
        [ -f "$real" ] || continue
        [ "$(dirname "$real")" = "$dir" ] || continue
        base="$(basename "$real")"
        case "$base" in
            ${name}_[0-9]*.exe) [ "$cand" != "$real" ] && rm -f "$cand"; continue ;;  # 已改过名
        esac
        ver="$(detect_ver "$real")" || ver="unknown"
        suf=""
        # 旧版本号与本包相同(8.5.11)时,改名为 _bak,避免被新装的覆盖
        [ "$ver" = "$PKGVER" ] && suf="_bak"
        if [ "$name" = "php" ] && [ "$ver" != "unknown" ]; then
            OLDVER="$ver"; OLDSUF="$suf"
        fi
        dest="$dir/${name}_${ver}${suf}.exe"
        if [ -e "$dest" ]; then
            # 目标已存在: 绝不覆盖,加时间戳另存
            dest="$dir/${name}_${ver}${suf}_$(date +%Y%m%d%H%M%S).exe"
        fi
        mv -f "$real" "$dest"
        log "$real -> $dest"
        [ "$cand" != "$real" ] && rm -f "$cand"
    done
}

relocate_script() {          # php-config / phpize 之类的脚本(无 .exe)
    local name="$1" dir="$2" f="$dir/$1"
    [ -f "$f" ] && [ ! -L "$f" ] || return 0
    [ -n "$OLDVER" ] || return 0
    local dest="${f}_${OLDVER}${OLDSUF}"
    [ -e "$dest" ] && dest="${dest}_$(date +%Y%m%d%H%M%S)"
    mv -f "$f" "$dest"
    log "$f -> $dest"
}

# php 必须最先处理,以便取得旧版本号 OLDVER
for n in php php-cgi phpdbg; do relocate_exe "$n" /usr/bin; done
relocate_exe php-fpm /usr/sbin
for n in php-config phpize; do relocate_script "$n" /usr/bin; done

# ---- 4. 建立链接 ----
mklink() {
    local target="$1" link="$2"
    [ -e "$target" ] || return 0
    ln -sf "$target" "$link"
    log "ln -s $target $link"
}
mklink "$PREFIX/bin/php.exe"     /usr/bin/php
mklink "$PREFIX/bin/php-cgi.exe" /usr/bin/php-cgi
mklink "$PREFIX/bin/phpdbg.exe"  /usr/bin/phpdbg
mklink "$PREFIX/bin/php-config"  /usr/bin/php-config
mklink "$PREFIX/bin/phpize"      /usr/bin/phpize
mklink "$PREFIX/sbin/php-fpm.exe" /usr/sbin/php-fpm

rm -f "$DLL_LIST"
log "完成: $(/usr/bin/php -v 2>/dev/null | head -1)"
exit 0
